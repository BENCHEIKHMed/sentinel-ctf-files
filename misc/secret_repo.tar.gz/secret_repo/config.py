# Configuration
DATABASE_URL = 'postgres://localhost/app'
DEBUG = False
# Secrets removed for security
