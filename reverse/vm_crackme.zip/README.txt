Reverse the VM interpreter and execute the bytecode to get the flag.
The VM has opcodes: PUSH(0x01), POP(0x02), ADD(0x03), XOR(0x04), CMP(0x05), JMP(0x06), HALT(0xFF), PRINT(0x07)
