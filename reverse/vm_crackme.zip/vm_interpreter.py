#!/usr/bin/env python3
"""Simple stack-based VM"""
import sys

PUSH  = 0x01
POP   = 0x02
ADD   = 0x03
XOR   = 0x04
CMP   = 0x05
JMP   = 0x06
HALT  = 0xFF
PRINT = 0x07

def run_vm(bytecode):
    pc = 0
    stack = []
    output = []
    while pc < len(bytecode):
        op = bytecode[pc]; pc += 1
        if op == PUSH:
            val = bytecode[pc]; pc += 1
            stack.append(val)
        elif op == POP:
            stack.pop()
        elif op == ADD:
            b = stack.pop(); a = stack.pop()
            stack.append((a + b) & 0xFF)
        elif op == XOR:
            b = stack.pop(); a = stack.pop()
            stack.append(a ^ b)
        elif op == PRINT:
            output.append(chr(stack[-1]))
        elif op == HALT:
            break
    return ''.join(output)

if __name__ == "__main__":
    bytecode = open("bytecode.bin", "rb").read()
    result = run_vm(list(bytecode))
    print("VM output:", result)
